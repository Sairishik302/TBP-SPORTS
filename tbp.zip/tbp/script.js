document.addEventListener("DOMContentLoaded", function() {
    // Hide the loader when the DOM content is loaded
    var loader = document.querySelector(".loader");
    loader.style.display = "none";
});
